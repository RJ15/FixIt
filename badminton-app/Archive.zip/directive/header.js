angular.module('badminton').directive('header', function () {
    'use strict'
    return {
        scope:true,
        templateUrl: 'directive/header-view.html'
    };
    
})